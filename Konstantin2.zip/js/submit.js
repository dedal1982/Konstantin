document
  .querySelector(".Job-openings__item")
  .addEventListener("click", function () {
    document.getElementById("myForm").submit();
  });
